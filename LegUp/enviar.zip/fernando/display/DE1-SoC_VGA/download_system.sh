quartus_pgm -c DE-SoC -m jtag ./DE1_SoC_VGA.cdf
